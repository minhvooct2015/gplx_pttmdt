<?php $__env->startSection('title','Danh sách lớp học'); ?>
<?php $__env->startSection('main'); ?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Danh sách lớp học</h1>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-xs-12 col-md-5 col-lg-5">
					<div class="panel panel-primary">
						<div class="panel-heading">
							Thêm lớp học
						</div>
						<div class="panel-body">
							 <?php echo $__env->make('errors.note', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							 <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-danger">
                                    
                                    <p><?php echo $message; ?></p>
                                </div>
                                <?php Session::forget('success');?>
                                <?php endif; ?>
							 <form role="form" method="post" enctype="multipart/form-data">
							 	 <?php echo e(csrf_field()); ?>

							 	 <div class="form-group">
								<label>Tên lớp học</label>
    							<input required type="text" name="name" class="form-control" placeholder="Tên lớp học...">
							</div>
							<div class="form-group">
								<label>Hạng xe</label>
    							<select name="hx" id="lth" class="form-control">
    										<option value="" disabled selected>Chọn hạng xe</option>
											<?php $__currentLoopData = $list1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($nt->hx_id); ?>"><?php echo e($nt->hx_ten); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
							<div class="form-group">
								<label>Giáo viên</label>
    							<select name="gv" id="lth" class="form-control">
    										<option value="" disabled selected>Chọn giáo viên</option>
											<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($nt->gv_id); ?>"><?php echo e($nt->gv_ten); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
							
							<div class="form-group">
    							 <button type="submit" class=" form-control btn btn-primary">Thêm</button>
							</div>
							</form>
							  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						</div>
					</div>
			</div>
			<div class="col-xs-12 col-md-7 col-lg-7">
				<div class="panel panel-primary">
					<div class="panel-heading">Danh sách lớp học </div>
					<div class="panel-body">
						<div class="bootstrap-table">
							<table class="table table-bordered">
				              	<thead>
					                <tr class="bg-primary">
					                	<th>Tên lớp học</th>
					                	<th>Tên giáo viên</th>
					                  <th>Tên hạng xe</th>
					                  
					                  <th style="width:30%">Tùy chọn</th>
					                </tr>
				              	</thead>
				              	<tbody>
				              		 <?php $__currentLoopData = $list2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($hx->lhlx_ten); ?></td>
                                <td><?php echo e($hx->gv_ten); ?></td>
                                
                                <td><?php echo e($hx->hx_ten); ?></td>
                                
                                    <td>
                                        <a href="<?php echo e(asset('/gplx/cbsh/sualophoc/'.$hx->lhlx_id)); ?>" class="btn btn-warning"><span class="glyphicon glyphicon-edit"></span> Sửa</a>
                                        <a href="<?php echo e(asset('/gplx/cbsh/xoalophoc/'.$hx->lhlx_id)); ?>" onclick="return confirm('Bạn có chắc chắn muốn xóa?')" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Xóa</a>
                                    </td>
                                </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                </tbody>
				                <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
				            </table>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
		</div><!--/.row-->
	</div>	<!--/.main-->
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('gplx.cbsh.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel/resources/views/gplx/cbsh/dslophoc.blade.php ENDPATH**/ ?>