<?php $__env->startSection('title','Sửa banner'); ?>
<?php $__env->startSection('main'); ?>
         <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">BANNER</h1>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-xs-12 col-md-12 col-lg-12">
				
				<div class="panel panel-primary">
					<div class="panel-heading">Sửa banner </div>
					<div class="panel-body">
						
						<form role="form" method="post" enctype="multipart/form-data">	
							<div class="row" style="margin-bottom:40px">
								<div class="col-xs-8">
									 <?php $__currentLoopData = $gv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="form-group" >
										<label>Banner ngang 1:</label>
										<input  id="img" type="file" name="b1" class="form-control " onchange="changeImg(this)">
										 <img id="avatar" width="100px" src="<?php echo e(asset('http://localhost/laravel/laravel/storage/app/anhBanner/'.$hx->ban_ngang1)); ?>" class="thumbnail">
									</div>
									<div class="form-group" >
										<label>Banner ngang 2:</label>
										<input  id="img" type="file" name="b2" class="form-control " onchange="changeImg(this)">
					                   <!--  <img id="avatar" class="thumbnail" width="300px" src="img/new_seo-10-512.png"> -->
					                    <img width="100px" src="<?php echo e(asset('http://localhost/laravel/laravel/storage/app/anhBanner/'.$hx->ban_ngang2)); ?>" class="thumbnail">
									</div>
									<div class="form-group" >
										<label>Banner trái 1:</label>
										<input  id="img" type="file" name="b3" class="form-control " onchange="changeImg(this)">
										<img width="100px" src="<?php echo e(asset('http://localhost/laravel/laravel/storage/app/anhBanner/'.$hx->ban_trai1)); ?>" class="thumbnail">
									</div>
									<div class="form-group" >
										<label>Banner trái 2:</label>
										<input  id="img" type="file" name="b4" class="form-control " onchange="changeImg(this)">
										<img width="100px" src="<?php echo e(asset('http://localhost/laravel/laravel/storage/app/anhBanner/'.$hx->ban_trai2)); ?>" class="thumbnail">
									</div>
									
									<div class="form-group" >
										<label>Banner trái 3:</label>
										<input  id="img" type="file" name="b5" class="form-control " onchange="changeImg(this)">
										<img width="100px" src="<?php echo e(asset('http://localhost/laravel/laravel/storage/app/anhBanner/'.$hx->ban_trai3)); ?>" class="thumbnail">
									</div>
									<div class="form-group" >
										<label>Banner trái 4:</label>
										<input  id="img" type="file" name="b6" class="form-control " onchange="changeImg(this)">
										<img width="100px" src="<?php echo e(asset('http://localhost/laravel/laravel/storage/app/anhBanner/'.$hx->ban_trai4)); ?>" class="thumbnail">
									</div>
									
									
									     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
									<input type="submit" name="submit" class=" btn btn-primary" value="Sửa" >
										<a href="<?php echo e(asset('/gplx/cbsh/dsbanner')); ?>"  class=" btn btn-danger">Hủy bỏ</a>
								</div>
							</div>
							<?php echo e(csrf_field()); ?>

							<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						</form>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
		</div><!--/.row-->
	</div>	<!--/.main-->
            
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('gplx.cbsh.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel/resources/views/gplx/cbsh/suabanner.blade.php ENDPATH**/ ?>