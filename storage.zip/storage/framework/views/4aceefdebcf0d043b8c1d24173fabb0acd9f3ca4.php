<?php $__env->startSection('title','Danh sách phiếu đăng ký'); ?>
<?php $__env->startSection('main'); ?>


<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Danh sách học viên thi đậu</h1>
            </div>
            
        </div><!--/.row-->
        
        <div class="row">
           
            <div class="col-xs-12 col-md-12 col-lg-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">Danh sách phiếu đăng ký </div>
                        <!-- <div class="col-lg-2 col-lg-offset-9" >
                           <h1> <a href="<?php echo e(asset('gplx/cbsh/themgiaovien')); ?>" class=" form-control btn btn-primary ">THÊM</a>
                            </h1>
                        </div> -->
                        <center>
                             <div class="form-group col-xs-4 col-xs-offset-3 row" >
                                        <!-- <label>Hạng xe</label> -->
                                        <br>
                                        
                               <select name="lt" id='nth' class="form-control">
                                            <option value="" disabled selected>Hiển thị phiếu đăng ký theo hạng xe ...</option>
                                             <?php $__currentLoopData = $list2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($nt->hx_id); ?>"><?php echo e($nt->hx_ten); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                  <!-- 
                                        <input type="text" class="form-control" name="nt" placeholder="Hiển thị phiếu đăng ký theo hạng xe ..." min="2000" max="2100" id='nth'> -->

                                    </div>
                        </center>
               
                   
                    <div class="panel-body">
                        <div class="bootstrap-table">
                            <table class="table table-bordered">
                                <thead>
                                    <tr class="bg-primary">
                                      <th >Họ và tên</th>
                                      <th >Số chứng minh nhân dân</th>
                                      <th>Hạng xe</th>
                                      
                                      <th >Chi tiết</th>
                                    </tr>
                                </thead>
                                <tbody id="lth">
                                 <?php $__currentLoopData = $list3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($hx->hoten); ?></td>
                                <td><?php echo e($hx->cmnd); ?></td>
                                <td><?php echo e($hx->hx_ten); ?></td>
                                <td>
                                        <a href="<?php echo e(asset('/gplx/cbsh/ctpdkdau/'.$hx->pdk_id)); ?>" class="btn btn-warning"><span class="glyphicon glyphicon-edit"></span> Chi tiết</a>
                                        
                                    </td>
                                    
                                </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            </table>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <?php echo e($list3->links()); ?>

            </div>
        </div><!--/.row-->
    </div>  <!--/.main-->
        
<?php $__env->stopSection(); ?>   
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function(){
        $("#nth").change(function(){
            var nam =$(this).val();
        $.get('http://127.0.0.1:8000/gplx/cbsh/pdkhxdau/'+nam,function(data){
                    $("#lth").html(data);
            });
        });

        // <?php echo e(asset('/gplx/cbsh/laynamthi/')); ?>

        
    });


</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('gplx.cbsh.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel/resources/views/gplx/cbsh/dspdkdau.blade.php ENDPATH**/ ?>