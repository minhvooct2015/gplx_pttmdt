<?php $__env->startSection('title','Trang chủ'); ?>
<?php $__env->startSection('main'); ?>
 <!-- Page Content -->
<div class="col-md-9">
                <div class="panel panel-warning vien">            
                    <div class="panel-heading" style="background-color:Tomato; color:white;" >
                        <h2 style="margin-top:0px; margin-bottom:0px;"> Chi tiết phiếu đăng ký</h2>
                    </div>

                    <div class="panel-body"style="background-color:Cornsilk;" >
                        <!-- item -->
          <div class="row">
            <div class="col-xs-12 col-md-10 col-lg-10">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            Chi tiết phiếu đăng ký
                        </div>
                        <div class="panel-body">
                            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <table border="1" class="table table-bordered">
                               <tr>
                                   
                                   <th>
                                       Hạng xe đăng ký
                                   </th>
                                   <td>
                                      <?php echo e($hx->hx_ten); ?>

                                   </td>
                               </tr>
                               <tr>
                                   
                                   <th>
                                       Tình trạng lệ phí thi
                                   </th>
                                   <td style="color:red">
                                    <?php if($hx->pdk_tinhtrangHP==0): ?>  
                                    <?php echo e(('Chưa đóng')); ?>

                                    <?php else: ?>
                                    <?php echo e(('Đã đóng')); ?> 
                                    <br> Số tiền: <?php echo e(number_format($hx->hx_giatien,0,',','.')); ?> VND
                                    <?php endif; ?>

                                </td>
                               </tr>
                               <tr>
                                   
                                   <th>
                                       Kết quả thi Lý Thuyết
                                   </th>
                                  <td>
                                    <?php if($hx->pdk_diemLT==0): ?>  
                                    <?php echo e(('Chưa có điểm')); ?>

                                    <?php else: ?>
                                    <?php echo e($hx->pdk_diemLT); ?>

                                    <?php endif; ?>

                                </td>
                               </tr>
                               <tr>
                                   
                                   <th>
                                       Kết quả thi Thực Hành
                                   </th>
                                   <td>
                                    <?php if($hx->pdk_diemTH==0): ?>  
                                    <?php echo e(('Chưa có điểm')); ?>

                                    <?php else: ?>
                                    <?php echo e($hx->pdk_diemTH); ?>

                                    <?php endif; ?>
                                   </td>
                               </tr>
                               <tr>
                                   
                                   <th>
                                       Kết quả 
                                   </th>
                                   <td style="color:red">
                                       <?php if($hx->pdk_diemTH >=18 && $hx->pdk_diemLT >=18 ): ?>  
                                    <?php echo e(('Đậu')); ?>

                                    <?php elseif($hx->pdk_diemTH ==0 && $hx->pdk_diemLT ==0 ): ?>
                                    <?php echo e(('')); ?>

                                    
                                     <?php else: ?>
                                    <?php echo e(('Trượt')); ?>



                                    <?php endif; ?>
                                   </td>
                               </tr>




                             
                           </table>
                        </div>
                    </div>
            </div>
            <div class="col-xs-12 col-md-10 col-lg-10">
                <div class="panel panel-primary">
                    <div class="panel-heading">Lịch học</div>
                    <div class="panel-body">
                        <div class="bootstrap-table">
                            <table class="table table-bordered">
                                <thead>
                                    <th >Ngày học</th>
                                      <th >Giờ học</th>
                                      <th>Chỗ học</th>
                                       <th>Địa chỉ</th>
                                      <th>Loại lịch học</th>
                                    </tr>
                                </thead>
                            
                                <tbody>
                                  <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($hx->lh_ngay); ?></td>
                                <td><?php echo e($hx->lh_giohocbatdau); ?></td>
                                <td><?php echo e($hx->ch_ten); ?></td>
                                <td><?php echo e($hx->ch_diachi); ?></td>
                                <td><?php echo e($hx->llh_ten); ?></td>
                                
                                </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </tbody>
                                <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                
                            </table>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-md-10 col-lg-10">
                <div class="panel panel-primary">
                    <div class="panel-heading">Lịch thi</div>
                    <div class="panel-body">
                        <div class="bootstrap-table">
                            <table class="table table-bordered">
                                <thead>
                                    <th >Ngày thi</th>
                                      <th >Giờ thi</th>
                                      <th>Chỗ thi</th>
                                      <th>Địa chỉ</th>
                                      <th>Hình thức thi</th>
                                    </tr>
                                </thead>
                            
                                <tbody>
                                  <?php $__currentLoopData = $list1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($hx->lt_ngaythi); ?></td>
                                <td><?php echo e($hx->lt_giothi); ?></td>
                                <td><?php echo e($hx->cth_ten); ?></td>
                                <td><?php echo e($hx->cth_diachi); ?></td>
                                 <td><?php echo e($hx->llh_ten); ?></td>
                                
                                </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </tbody>
                                <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                
                            </table>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div><!--/.row-->
    </div>
    <!-- end Page Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('gplx.nguoidung.masterfront', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel/resources/views/gplx/nguoidung/chitietpdk.blade.php ENDPATH**/ ?>