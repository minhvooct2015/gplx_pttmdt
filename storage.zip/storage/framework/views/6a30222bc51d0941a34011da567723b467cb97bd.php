<?php $__env->startSection('title','Sửa lịch học'); ?>
<?php $__env->startSection('main'); ?>
         <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">GIÁO VIÊN</h1>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-xs-12 col-md-12 col-lg-12">
				
				<div class="panel panel-primary">
					<div class="panel-heading">Sửa giáo viên </div>
					<div class="panel-body">
						
						<form role="form" method="post" enctype="multipart/form-data">
							<div class="row" style="margin-bottom:40px">
								<div class="col-xs-8">
									
									<div class="form-group" >
										<label>Chỗ học</label>
										<select name="ch" id="lth" class="form-control">
											<option value="" disabled selected>Chọn lịch thi</option>
											<?php $__currentLoopData = $list1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($cate->ch_id); ?>" <?php if($lt->id_ch==$cate->ch_id): ?>  selected <?php endif; ?>><?php echo e($cate->ch_ten); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
										
									</div>
									<div class="form-group" >
										<label>Lớp học lái xe </label>
										<select name="lhlx" id="lth" class="form-control">
											<option value="" disabled selected>Chọn lớp học</option>
											<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($nt->lhlx_id); ?>" <?php if($lt->id_lhlx==$nt->lhlx_id): ?>  selected <?php endif; ?>><?php echo e($nt->lhlx_ten); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
					                   
									</div>
									<div class="form-group" >
										<label>Loại lịch học</label><br>
										<?php $__currentLoopData = $list2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php echo e($nt->llh_ten); ?> <input type="radio" name="llh" value="<?php echo e($nt->llh_id); ?>" <?php if($lt->id_llh==$nt->llh_id): ?>  checked="checked" <?php endif; ?>> 
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
									<div class="form-group">
								<label>Ngày học</label>
    							<input required name="ngh" class="form-control datepicker" placeholder="Ngày thi..." type="text" value="<?php echo e($lt->lh_ngay); ?>">
							</div>
							<div class="form-group">
								<label>Giờ học</label>
    							<input required class="form-control timepicker"type="text" name="gh" placeholder="Giờ học..." value="<?php echo e($lt->lh_giohocbatdau); ?>">
							</div>
									<input type="submit" name="submit" value="Thêm" class="btn btn-primary">
									<input type="reset" value="Làm mới" class="btn btn-danger">
								</div>
							</div>
							<?php echo e(csrf_field()); ?>

							<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						</form>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
		</div><!--/.row-->
	</div>	<!--/.main-->
            
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('gplx.cbsh.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel/resources/views/gplx/cbsh/sualichhoc.blade.php ENDPATH**/ ?>