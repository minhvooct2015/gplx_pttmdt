<?php $__env->startSection('title','Sửa mô tả hạng xe'); ?>
<?php $__env->startSection('main'); ?>
        
    <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Sửa mô tả hạng xe</h1>
            </div>
        </div><!--/.row-->
        
        <div class="row">
            <div class="col-xs-12 col-md-12 col-lg-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            Sửa mô tả hạng xe
                        </div>
                        <div class="panel-body">
                            <?php echo $__env->make('errors.note', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                         <form role="form" method="post" enctype="multipart/form-data">  
                            <div class="row" style="margin-bottom:40px">
                                <div class="col-xs-8">
                                    <div class="form-group" >
                                        <label>Hạng xe</label>
                                        <select name="hx" id="lth" class="form-control">
                                            <option value="" disabled selected>Chọn hạng xe</option>
                                            <?php $__currentLoopData = $list1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($nt->hx_id); ?>" <?php if($lt->id_hx==$nt->hx_id): ?>  selected <?php endif; ?>><?php echo e($nt->hx_ten); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group" >
                                        <label>Ảnh minh họa</label>
                                        <input  id="img" type="file" name="img" class="form-control " onchange="changeImg(this)">
                                       <img width="100px" src="<?php echo e(asset('http://localhost/laravel/laravel/storage/app/anhHX/'.$lt->mthx_anh)); ?>" class="thumbnail">
                                    </div>
                                    <div class="form-group" >
                                        <label>Nội dung mô tả</label>
                                        <textarea class=" form-control ckeditor"   name="mota" >
                                            <?php echo e($lt->mthx_chitiet); ?>

                                        </textarea >
                                    </div>
                                    
                                    
                                     <input type="submit" name="submit" value="Sửa" class="btn btn-primary">
                                    <a href="<?php echo e(asset('gplx/cbsh/dsmota')); ?>"  class=" btn btn-danger">Hủy bỏ</a>
                                </div>
                            </div>
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        </form>
                            
                        </div>
                    </div>
            </div>
        </div><!--/.row-->
    </div>  <!--/.main-->
<?php $__env->stopSection(); ?>   
<?php echo $__env->make('gplx.cbsh.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel/resources/views/gplx/cbsh/suamthx.blade.php ENDPATH**/ ?>