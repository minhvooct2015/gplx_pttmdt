<?php $__env->startSection('title','Trang chủ'); ?>
<?php $__env->startSection('main'); ?>
 <!-- Page Content -->
<div class="col-md-9">
                <div class="panel panel-warning vien">            
                    <div class="panel-heading" style="background-color:Tomato; color:white;" >
                        <h2 style="margin-top:0px; margin-bottom:0px;"> Danh sách phiếu đăng ký</h2>
                    </div>

                    <div class="panel-body"style="background-color:Cornsilk;" >
                        <!-- item -->
                <div class="row">
           
            <div class="col-xs-12 col-md-12 col-lg-12">
                <div class="panel panel-primary">
                        <div class="col-lg-2 col-lg-offset-9" >
                           <h1> <a href="<?php echo e(asset('gplx/nguoidung/thempdk')); ?>" class=" form-control btn btn-primary ">Đăng ký học</a>
                            </h1>
                        </div>
               
                
                   
                    <div class="panel-body">
                        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="bootstrap-table">
                            <table class="table table-bordered">
                                <thead>
                                    <tr class="bg-primary">
                                      
                                      <th >Hạng xe đăng ký</th>
                                      <th >Học phí</th>
                                      <th>Tình trạng học phí</th>
                                      
                                      <th ">Tùy chọn</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($hx->hx_ten); ?></td>
                                <td><?php echo e(number_format($hx->hx_giatien,0,',','.')); ?></td>
                                <td style="color:red">
                                    <?php if($hx->pdk_tinhtrangHP==0): ?>  
                                    <?php echo e(('Chưa đóng')); ?>

                                    <?php else: ?>
                                    <?php echo e(('Đã đóng')); ?>

                                     <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-success">
                                    
                                    <p><?php echo $message; ?></p>
                                </div>
                               
                                <?php endif; ?>
                                    <?php endif; ?>

                                </td>
                                    <td>
                                       <!--  <a href="<?php echo e(asset('/gplx/nguoidung/suablx/'.$hx->pdk_id)); ?>" class="btn btn-warning"><span class="glyphicon glyphicon-edit"></span> Sửa</a> -->
                                        
                                        <?php if($hx->pdk_tinhtrangHP==0): ?>  
                                        <a href="<?php echo e(asset('/gplx/nguoidung/vnpay/'.$hx->pdk_id)); ?>" class="btn btn-warning"><span class="glyphicon glyphicon-edit"></span> Đóng tiền học</a>
                                        <?php endif; ?>
                                        <a href="<?php echo e(asset('/gplx/nguoidung/chitietpdk/'.$hx->pdk_id)); ?>" class="btn btn-success"><span class="glyphicon glyphicon-edit"></span> Xem chi tiết</a>
                                        <a href="<?php echo e(asset('/gplx/nguoidung/xoapdk/'.$hx->pdk_id)); ?>" onclick="return confirm('Bạn có chắc chắn muốn xóa?')" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Xóa</a>
                                    </td>
                                </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            </table>

                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <?php echo e($list->links()); ?>

            </div>
        </div><!--/.row-->
    </div>
    <!-- end Page Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('gplx.nguoidung.masterfront', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel/resources/views/gplx/nguoidung/dsphieudangky.blade.php ENDPATH**/ ?>