<?php if(Session::has('error')): ?>
 <p class="alert alert-danger"><?php echo e(Session::get('error')); ?></p>
<?php echo e(csrf_field()); ?>

<!-- <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
 --><?php endif; ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p class="alert alert-danger"><?php echo e($error); ?></p>
<?php echo e(csrf_field()); ?>

<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel/resources/views/errors/note.blade.php ENDPATH**/ ?>