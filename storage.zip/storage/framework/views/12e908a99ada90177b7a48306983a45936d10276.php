
<?php $__env->startSection('title','Danh sách hạng xe'); ?>
<?php $__env->startSection('main'); ?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Danh sách hạng xe</h1>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-xs-12 col-md-5 col-lg-5">
					<div class="panel panel-primary">
						<div class="panel-heading">
							Thêm hạng xe
						</div>
						<div class="panel-body">
							 <?php echo $__env->make('errors.note', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							 <form role="form" method="post" enctype="multipart/form-data">
							 	 <?php echo e(csrf_field()); ?>

							<div class="form-group">
								<label>Tên hạng xe:</label>
    							<input required type="text" name="name" class="form-control" placeholder="Tên hạng xe...">
							</div>
							<div class="form-group">
								<label>Giá tiền:</label>
    							<input  required type="number" name="gia" class="form-control" placeholder="Giá tiền..." >
							</div>
							<div class="form-group">
    							 <button type="submit" class=" form-control btn btn-primary">Thêm</button>
							</div>
							</form>
							  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						</div>
					</div>
			</div>
			<div class="col-xs-12 col-md-7 col-lg-7">
				<div class="panel panel-primary">
					<div class="panel-heading">Danh sách hạng xe</div>
					<div class="panel-body">
						<div class="bootstrap-table">
							<table class="table table-bordered">
				              	<thead>
					                <tr class="bg-primary">
					                  <th>Tên hạng xe</th>
					                  <th>Giá tiền</th>
					                  <th style="width:30%">Tùy chọn</th>
					                </tr>
				              	</thead>
				              	<tbody>
				              		 <?php $__currentLoopData = $hxlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>

                                <td><?php echo e($hx->hx_ten); ?></td>
                                <td><?php echo e(number_format($hx->hx_giatien,0,',','.')); ?> VND</td>
									<td>
			                    		<a href="<?php echo e(asset('/gplx/cbsh/suahangxe/'.$hx->hx_id)); ?>" class="btn btn-warning"><span class="glyphicon glyphicon-edit"></span> Sửa</a>
			                    		<a href="<?php echo e(asset('/gplx/cbsh/xoahangxe/'.$hx->hx_id)); ?>" onclick="return confirm('Bạn có chắc chắn muốn xóa?')" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Xóa</a>
			                  		</td>
			                  	</tr>
			                  	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                </tbody>
				                <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
				            </table>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
		</div><!--/.row-->
	</div>	<!--/.main-->
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('gplx.cbsh.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel/resources/views/gplx/cbsh/dshxe.blade.php ENDPATH**/ ?>