<?php $__env->startSection('title','Sắp lịch thi cho lớp học'); ?>
<?php $__env->startSection('main'); ?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Sắp lịch thi cho lớp học</h1>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-xs-12 col-md-5 col-lg-5">
					<div class="panel panel-primary">
						<div class="panel-heading">
							Sắp lịch thi cho lớp học
						</div>
							<div class="panel-body">
								<?php echo $__env->make('errors.note', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								<?php if($message = Session::get('success')): ?>
                                <div class="alert alert-danger">
                                    
                                    <p><?php echo $message; ?></p>
                                </div>
                                <?php Session::forget('success');?>
                                <?php endif; ?>
						<div class="form-group col-xs-8 row" >
										<label>Năm thi</label>
										<input type="number" class="form-control" name="nt" placeholder="Chọn năm ..." min="2000" max="2100" id='nth'>

									</div>
						<form role="form" method="post" enctype="multipart/form-data">
							<div class="row" style="margin-bottom:40px">
								<div class="col-xs-8">
									
									<div class="form-group" >
										<label>Lịch thi</label>
										<select name="lt" id="lth" class="form-control">
											<option value="" disabled selected>Chọn lịch thi</option>
											<?php $__currentLoopData = $ngaythi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($nt->lt_id); ?>"><?php echo e($nt->lt_ngaythi); ?>-<?php echo e($nt->llh_ten); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
										
									</div>
									<div class="form-group" >
										<label>Lớp học lái xe :</label>
										<select name="lh" id="lth" class="form-control">
											<option value="" disabled selected>Chọn lớp học</option>
											<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($nt->lhlx_id); ?>"><?php echo e($nt->lhlx_ten); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
					                   
									</div>
									<input type="submit" name="submit" value="Thêm" class="btn btn-primary">
									<input type="reset" value="Làm mới" class="btn btn-danger">
								</div>
							</div>
							<?php echo e(csrf_field()); ?>

							<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						</form>
						<div class="clearfix"></div>
					</div>
					</div>
			</div>
			<div class="col-xs-12 col-md-7 col-lg-7">
				<div class="panel panel-primary">
					<div class="panel-heading">Danh sách lịch thi lớp học </div>
					<div class="panel-body">
						<div class="bootstrap-table">
							<table class="table table-bordered">
				              	<thead>
					                <tr class="bg-primary">
					                	<th>Tên lớp học</th>
					                	<th>Lịch thi</th>
					                  	<th>Hình thức thi</th>
					                  
					                  <th style="width:30%">Tùy chọn</th>
					                </tr>
				              	</thead>
				              	<tbody>
				              		 <?php $__currentLoopData = $list2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($hx->lhlx_ten); ?></td>
                                <td><?php echo e($hx->lt_ngaythi); ?></td>
                                <td><?php echo e($hx->llh_ten); ?></td>
                   
                                
                                    <td>
                                        <a href="<?php echo e(asset('/gplx/cbsh/sualichthilophoc/'.$hx->ltlh_id)); ?>" class="btn btn-warning"><span class="glyphicon glyphicon-edit"></span> Sửa</a>
                                        <a href="<?php echo e(asset('/gplx/cbsh/xoaltlh/'.$hx->ltlh_id)); ?>" onclick="return confirm('Bạn có chắc chắn muốn xóa?')" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Xóa</a>
                                    </td>
                                </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                </tbody>
				                <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
				            </table>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
		</div><!--/.row-->
	</div>	<!--/.main-->
<?php $__env->stopSection(); ?>	

<?php $__env->startSection('script'); ?>
<script>
	$(document).ready(function(){
		$("#nth").change(function(){
			var nam =$(this).val();
		$.get('http://127.0.0.1:8000/gplx/cbsh/laynamthi/'+nam,function(data){
					$("#lth").html(data);
			});
		});

		// <?php echo e(asset('/gplx/cbsh/laynamthi/')); ?>

		
	});


</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('gplx.cbsh.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel/resources/views/gplx/cbsh/saplichthilophoc.blade.php ENDPATH**/ ?>