<?php $__env->startSection('title','Sửa lớp học'); ?>
<?php $__env->startSection('main'); ?>
         <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header"> Sửa lịch thi lớp học</h1>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-xs-12 col-md-12 col-lg-12">
				
				<div class="panel panel-primary">
					<div class="panel-heading">Sửa lớp học </div>
					<div class="panel-body">
						<form role="form" method="post" enctype="multipart/form-data">
							<div class="row" style="margin-bottom:40px">
								<div class="col-xs-8">
									
									<div class="form-group" >
										<label>Lịch thi</label>
										<select name="lt" id="lth" class="form-control">
											<?php $__currentLoopData = $list1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

											<option value="<?php echo e($cate->lt_id); ?>" <?php if($lt->id_lt==$cate->lt_id): ?>  selected <?php endif; ?>><?php echo e($cate->lt_ngaythi); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											
										</select>
										
									</div>
									<div class="form-group" >
										<label>Lớp học lái xe :</label>
										<select name="lh" id="lth" class="form-control">
											<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

											<option value="<?php echo e($cate->lhlx_id); ?>" <?php if($lt->id_lhlx==$cate->lhlx_id): ?>  selected <?php endif; ?>><?php echo e($cate->lhlx_ten); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
					                   
									</div>
									<input type="submit" name="submit" value="Thêm" class="btn btn-primary">
									<input type="reset" value="Làm mới" class="btn btn-danger">
								</div>
							</div>
							<?php echo e(csrf_field()); ?>

							<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						</form>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
		</div><!--/.row-->
	</div>	<!--/.main-->
            
<?php $__env->stopSection(); ?>	

<?php echo $__env->make('gplx.cbsh.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel/resources/views/gplx/cbsh/sualichthilophoc.blade.php ENDPATH**/ ?>