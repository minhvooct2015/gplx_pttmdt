<?php $__env->startSection('title','Danh sách banner'); ?>
<?php $__env->startSection('main'); ?>


<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Danh sách banner</h1>
            </div>
            
        </div><!--/.row-->
        
        <div class="row">
           
            <div class="col-xs-12 col-md-12 col-lg-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">Danh sách banner</div>
                        <div class="col-lg-2 col-lg-offset-9" >
                           <h1> <a href="<?php echo e(asset('gplx/cbsh/banner')); ?>" class=" form-control btn btn-primary ">THÊM</a>
                            </h1>
                        </div>
                
                   
                    <div class="panel-body">
                        <div class="bootstrap-table">
                            <table class="table table-bordered">
                                <thead>
                                    <tr class="bg-primary">
                                      <th style="width:15%">Banner ngang 1</th>
                                      <th  >Banner ngang 2</th>
                                      <th>Banner dọc 1</th>
                                      <th>Banner dọc 2</th>
                                      <th>Banner dọc 3</th>
                                     <th>Banner dọc 4</th>

                                      <th style="width:20%">Tùy chọn</th>
                                    </tr>
                                </thead>
                                <tbody> 
                                   <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td>
                                <img width="100px" src="<?php echo e(asset('http://localhost/laravel/laravel/storage/app/anhBanner/'.$hx->ban_ngang1)); ?>" class="thumbnail">
                                </td>
                                <td>
                                <img width="100px" src="<?php echo e(asset('http://localhost/laravel/laravel/storage/app/anhBanner/'.$hx->ban_ngang2)); ?>" class="thumbnail">
                                </td>
                                <td>
                                <img width="100px" src="<?php echo e(asset('http://localhost/laravel/laravel/storage/app/anhBanner/'.$hx->ban_trai1)); ?>" class="thumbnail">
                                </td>
                                <td>
                                <img width="100px" src="<?php echo e(asset('http://localhost/laravel/laravel/storage/app/anhBanner/'.$hx->ban_trai2)); ?>" class="thumbnail">
                                </td>
                                <td>
                                <img width="100px" src="<?php echo e(asset('http://localhost/laravel/laravel/storage/app/anhBanner/'.$hx->ban_trai3)); ?>" class="thumbnail">
                                </td>
                                <td>
                                <img width="100px" src="<?php echo e(asset('http://localhost/laravel/laravel/storage/app/anhBanner/'.$hx->ban_trai4)); ?>" class="thumbnail">
                                </td>
                                    <td>
                                        <?php if($hx->ban_trangthai==0): ?>
                                        <p>
                                        <a href="<?php echo e(asset('/gplx/cbsh/Showbanner/'.$hx->ban_id)); ?>" class="btn btn-success"><span class="glyphicon glyphicon-edit"></span> Hiển thị</a>
                                        </p>
                                        <?php else: ?>
                                        
                                            <b class="btn btn-success" style="background-color:#FF6347 ; color:#F0F8FF"> Đang được sử dụng</b>
                                        
                                        <?php endif; ?>
                                        <a href="<?php echo e(asset('/gplx/cbsh/suabanner/'.$hx->ban_id)); ?>" class="btn btn-warning"><span class="glyphicon glyphicon-edit"></span> Sửa</a>
                                        <a href="<?php echo e(asset('/gplx/cbsh/xoabanner/'.$hx->ban_id)); ?>" onclick="return confirm('Bạn có chắc chắn muốn xóa?')" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Xóa</a>
                                    </td>
                                </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            </table>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div><!--/.row-->
    </div>  <!--/.main-->
        
<?php $__env->stopSection(); ?>   
<?php echo $__env->make('gplx.cbsh.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel/resources/views/gplx/cbsh/dsbanner.blade.php ENDPATH**/ ?>