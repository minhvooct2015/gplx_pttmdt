<?php $__env->startSection('title','Trang chủ'); ?>
<?php $__env->startSection('main'); ?>


<div class="col-md-9">
	            <div class="panel panel-warning vien">            
	            	<div class="panel-heading" style="background-color:Tomato; color:white;" >
	            		<h2 style="margin-top:0px; margin-bottom:0px;">Thông tin cá nhân</h2>
	            	</div>

	            	<div class="panel-body"style="background-color:Cornsilk;" >
	            			   <div class="panel-body">
                        <div class="bootstrap-table">
                            <table class="table table-bordered" id="vientable">
                                <thead>
                                    <tr >
                                      
                                     <th >Họ tên</th>
                                     	<td><?php echo e(Auth::user()->hoten); ?></td>
									 </tr>

										<tr>
											<th  >Ngày sinh</th> 
								    			<td><?php echo e(Auth::user()->ngaysinh); ?></td>
								    	</tr> 





								    	<tr>
								    		  <th  >Email</th>
								    				<td><?php echo e(Auth::user()->email); ?></td>
								    	</tr>
								    	
								    	<tr>
								    		<th  >Hộ khẩu</th>
								    	<td><?php echo e(Auth::user()->hokhau); ?></td>

								    	</tr>

								    	<tr>
								    		 <th  >Số chứng minh nhân dân</th>
								    			<td><?php echo e(Auth::user()->cmnd); ?></td>
								    	</tr>

								    	<tr>
								    		<th >Nơi ở hiện tại</th>
								    	<td><?php echo e(Auth::user()->noio); ?></td>

								    	</tr>


								    	<tr>
								    		<th >Số điện thoại</th>
								    	<td><?php echo e(Auth::user()->sodienthoai); ?></td>
								    	</tr>
								    
								  
								    
								   
								    
								    
                                   
                                </thead>
                                <tbody>
                                  
                                  
                                  
                                  
                                   
                                  
                                  
                                </tbody>
                                <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            </table>
                        </div>
                        <div class="clearfix"></div>
                    </div>

					</div>
	            </div>
        	</div>
<?php $__env->stopSection(); ?>   
<?php echo $__env->make('gplx.nguoidung.masterfront', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel/resources/views/gplx/nguoidung/ttcanhan.blade.php ENDPATH**/ ?>