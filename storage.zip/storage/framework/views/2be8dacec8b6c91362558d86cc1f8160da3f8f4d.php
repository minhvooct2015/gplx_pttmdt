<?php $__env->startSection('title','Danh sách lịch thi'); ?>
<?php $__env->startSection('main'); ?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Danh sách lịch thi</h1>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-xs-12 col-md-5 col-lg-4">
					<div class="panel panel-primary">
						<div class="panel-heading">
							Thêm lịch thi
						</div>
						<div class="panel-body">
							 <?php echo $__env->make('errors.note', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							 <form role="form" method="post" enctype="multipart/form-data">
							 	 <?php echo e(csrf_field()); ?>

							<div class="form-group">
								<label>Ngày thi:</label>
    							<input required name="ngt" class="form-control datepicker" placeholder="Ngày thi..." type="text" >
							</div>
							<div class="form-group">
								<label>Giờ thi:</label>
    							<input required class="form-control timepicker"type="time" name="gt" placeholder="Giờ thi...">
							</div>
							<div class="form-group">
								<label>Loại thi:</label>
    							<select  name="llt" class="form-control">
    										<option value="" disabled selected>Chọn loại thi</option>
											<?php $__currentLoopData = $list1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($cate->llh_id); ?>"><?php echo e($cate->llh_ten); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                    </select>
							</div>
							<div class="form-group" >
										<label>Chỗ thi</label>
										<select  name="dc" class="form-control">
											<option value="" disabled selected>Chọn  thi</option>
											<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($cate->cth_id); ?>"><?php echo e($cate->cth_ten); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                    </select>
									</div>
							<div class="form-group">
    							 <button type="submit" class=" form-control btn btn-primary">Thêm</button>
							</div>
							</form>
							  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						</div>
					</div>
			</div>
			<div class="col-xs-12 col-md-7 col-lg-8">
				<div class="panel panel-primary">
					<div class="panel-heading">Danh sách lịch thi </div>
					<div class="panel-body">
						<div class="bootstrap-table">
							<table class="table table-bordered">
				              	<thead>
					                <tr class="bg-primary">
					                  <th>Ngày thi</th>
					                   <th>Giờ thi</th>
					                   <th style="width:25%">Chỗ thi</th>
					                   <th style="width:15%">Hình thức thi</th>
					                  <th >Tùy chọn</th>
					                </tr>
				              	</thead>
				              	<tbody>
				              		 <?php $__currentLoopData = $hxlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>

									<td><?php echo e($hx->lt_ngaythi); ?></td>
                                	<td><?php echo e($hx->lt_giothi); ?></td>
                                	<td><?php echo e($hx->cth_ten); ?></td>
                                	<td><?php echo e($hx->llh_ten); ?></td>
									<td>
			                    		<a href="<?php echo e(asset('/gplx/cbsh/sualth/'.$hx->lt_id)); ?>" class="btn btn-warning"><span class="glyphicon glyphicon-edit"></span> Sửa</a>
			                    		<a href="<?php echo e(asset('/gplx/cbsh/xoalth/'.$hx->lt_id)); ?>" onclick="return confirm('Bạn có chắc chắn muốn xóa?')" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Xóa</a>
			                  		</td>
			                  	</tr>
			                  	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                </tbody>
				                <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
				            </table>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
		</div><!--/.row-->
	</div>	<!--/.main-->
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('gplx.cbsh.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel/resources/views/gplx/cbsh/lichthi.blade.php ENDPATH**/ ?>