<?php $__env->startSection('title','Thêm hạng xe'); ?>
<?php $__env->startSection('main'); ?>

<!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 clatruepage-header">Hạng xe
                            <small>Thêm</small>
                        </h1>
                    </div>
                    <!-- /.col-lg-12 -->
                    <div class="col-lg-7" style="padding-bottom:120px">
                        <?php echo $__env->make('errors.note', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <form role="form" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label>Tên hạng xe</label>
                                <input required class="form-control" name="name" placeholder="Vui lòng nhập tên hạng xe cần thêm" />
                            </div>
                            
                            <button type="submit" class=" form-control btn btn-primary">Thêm</button>
                            <!-- <button type="reset" class="btn btn-default">Làm mới</button> -->
                        </form>

                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('gplx.cbsh.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel/resources/views/gplx/cbsh/themHangxe.blade.php ENDPATH**/ ?>