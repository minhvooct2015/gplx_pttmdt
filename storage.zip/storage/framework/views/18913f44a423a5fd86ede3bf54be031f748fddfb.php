<?php $__env->startSection('title','Phân công giáo viên gác thi'); ?>
<?php $__env->startSection('main'); ?>
         <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Phân công giáo viên gác thi</h1>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-xs-12 col-md-12 col-lg-12">
				
				<div class="panel panel-primary">
					<div class="panel-heading">Phân công giáo viên gác thi </div>
					<div class="panel-body">
						<?php if($message = Session::get('success')): ?>
                                <div class="alert alert-danger">
                                    
                                    <p><?php echo $message; ?></p>
                                </div>
                                <?php Session::forget('success');?>
                                <?php endif; ?>
						<div class="form-group col-xs-8 row" >
										<label>Năm thi</label>
										<input type="number" class="form-control" name="nt" placeholder="Chọn năm ..." min="2000" max="2100" id='nth'>

									</div>
						<form role="form" method="post" enctype="multipart/form-data">
							<div class="row" style="margin-bottom:40px">
								<div class="col-xs-8">
									
									<div class="form-group" >
										<label>Lịch thi</label>
										<select name="lt" id="lth" class="form-control">
											<option value="" disabled selected>Chọn lịch thi</option>
											<?php $__currentLoopData = $ngaythi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($nt->lt_id); ?>"><?php echo e($nt->lt_ngaythi); ?>-<?php echo e($nt->llh_ten); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
										
									</div>
									<div class="form-group" >
										<label>Giáo viên</label>
										<select name="gv" id="lth" class="form-control">
											<option value="" disabled selected>Chọn giáo viên</option>
											<?php $__currentLoopData = $gv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($nt->gv_id); ?>"><?php echo e($nt->gv_ten); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
					                   
									</div>
									<input type="submit" name="submit" value="Thêm" class="btn btn-primary">
									<input type="reset" value="Làm mới" class="btn btn-danger">
								</div>
							</div>
							<?php echo e(csrf_field()); ?>

							<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						</form>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
		</div><!--/.row-->
	</div>	<!--/.main-->
            
<?php $__env->stopSection(); ?>	

<?php $__env->startSection('script'); ?>
<script>
	$(document).ready(function(){
		$("#nth").change(function(){
			var nam =$(this).val();
		$.get('http://127.0.0.1:8000/gplx/cbsh/laynamthi/'+nam,function(data){
					$("#lth").html(data);
			});
		});

		// <?php echo e(asset('/gplx/cbsh/laynamthi/')); ?>

		
	});


</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('gplx.cbsh.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel/resources/views/gplx/cbsh/sapLT.blade.php ENDPATH**/ ?>