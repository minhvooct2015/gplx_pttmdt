
<?php $__env->startSection('title','Trang chủ'); ?>
<?php $__env->startSection('main'); ?>


<div class="col-md-9">
	            <div class="panel panel-warning vien">            
	            	<div class="panel-heading" style="background-color:Tomato; color:white;" >
	            		<h2 style="margin-top:0px; margin-bottom:0px;">KHÓA HỌC</h2>
	            	</div>

	            	<div class="panel-body"style="background-color:Cornsilk;" >
	            		<!-- item -->
					    <div class="row-item row">
					    	<?php $__currentLoopData = $list1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                	<h3>
		                		 LỚP HỌC LÁI XE HẠNG <?php echo e($cate->hx_ten); ?></a> 
		                	</h3>
		                	<div class="col-md-8 border-right">
		                		<div class="col-md-5">
			                        
			                            <!-- <img class="img-responsive" src="image/320x150.png" alt=""> -->
			                            <img  	height="150px" width="150px" src="<?php echo e(asset('http://localhost/laravel/laravel/storage/app/anhHX/'.$cate->mthx_anh)); ?>" class="thumbnail">
			                        
			                    </div>

			                    <div class="col-md-7">
			                   
			                        <p>
			                        	<?php echo $cate->mthx_chitiet; ?>

			                        </p>
			                        <a class="btn btn-success" href="<?php echo e(asset('gplx/nguoidung/thempdk/'.$cate->hx_id)); ?>">Đăng ký học<span class="glyphicon glyphicon-chevron-right"></span></a>
								</div>

		                	</div>
		                    
							<div class="break"></div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                </div>
		                <!-- end item -->
		               
		               
		                
						<?php echo e($list1->links()); ?>

					</div>
	            </div>
        	</div>
<?php $__env->stopSection(); ?>   
<?php echo $__env->make('gplx.nguoidung.masterfront', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel/resources/views/gplx/nguoidung/home.blade.php ENDPATH**/ ?>