<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class gplx_giaovien extends Model
{
    //
    protected $table='cbsh_giaovien';
    protected $primaryKey='gv_id';
    protected $guarded=[];
}
