<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class gplx_banglaixe extends Model
{
    //
     protected $table='gplx_banglaixe';
    protected $primaryKey='blx_id';
    protected $guarded=[];
}
