<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class nguoidung extends Model
{
    //
     protected $table='nguoidung';
    protected $primaryKey='nd_id';
    protected $guarded=[];
}
