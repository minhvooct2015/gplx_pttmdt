<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class gplx_chohoc extends Model
{
    //
     protected $table='cbsh_chohoc';
    protected $primaryKey='ch_id';
    protected $guarded=[];
}
