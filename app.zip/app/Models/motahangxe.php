<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class motahangxe extends Model
{
    //
    protected $table='motahangxe';
    protected $primaryKey='mthx_id';
    protected $guarded=[];
}
