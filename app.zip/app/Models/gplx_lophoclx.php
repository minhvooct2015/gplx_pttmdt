<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class gplx_lophoclx extends Model
{
    //
     protected $table='cbsh_lophoclx';
    protected $primaryKey='lhlx_id';
    protected $guarded=[];
}
