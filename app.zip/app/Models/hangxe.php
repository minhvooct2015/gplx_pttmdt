<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class hangxe extends Model
{
    //
    protected $table='cbsh_hangxe';
    protected $primaryKey='hx_id';
    protected $guarded=[];
}
