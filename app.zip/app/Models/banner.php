<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class banner extends Model
{
    //
    protected $table='banner';
    protected $primaryKey='ban_id';
    protected $guarded=[];
}
