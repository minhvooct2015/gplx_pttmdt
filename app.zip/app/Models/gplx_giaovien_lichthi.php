<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class gplx_giaovien_lichthi extends Model
{
    //
    protected $table='cbsh_giaovien_Lichthi';
    protected $primaryKey ='gvlt_id' ;
    protected $guarded=[]; 
    // ['id_gv', 'id_lt']
}
