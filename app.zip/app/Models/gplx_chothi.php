<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class gplx_chothi extends Model
{
    //
    protected $table='cbsh_chothi';
    protected $primaryKey='cth_id';
    protected $guarded=[];
}
