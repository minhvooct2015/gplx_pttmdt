<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class gplx_lichhoc extends Model
{
    //  
    protected $table='cbsh_lichhoc';
    protected $primaryKey='lh_id';
    protected $guarded=[];

}
