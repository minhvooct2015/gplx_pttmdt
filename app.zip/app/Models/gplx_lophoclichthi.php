<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class gplx_lophoclichthi extends Model
{
    //
    protected $table='cbsh_lichthi_lophoc';
    protected $primaryKey='ltlh_id';
    protected $guarded=[];
}
