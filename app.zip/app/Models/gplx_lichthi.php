<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class gplx_lichthi extends Model
{
    //
    protected $table='cbsh_lichthi';
    protected $primaryKey='lt_id';
    protected $guarded=[];
}
