<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class gplx_loailichhoc extends Model
{
    //
     protected $table='cbsh_loailichhoc';
    protected $primaryKey='llh_id';
    protected $guarded=[];
}
